import pandas as pd
import numpy as np
from pyecharts.charts import Line, Pie, Bar, Map
from pyecharts import options as opts
from pyecharts.globals import ThemeType
from snapshot_selenium import snapshot as driver
from pyecharts.render import make_snapshot
from pyecharts.charts import Page
from bs4 import BeautifulSoup
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.model_selection import train_test_split

data = pd.read_excel("城市疫情数据.xlsx", sheet_name='城市疫情')

df = pd.read_csv('全省数据.csv', encoding='gbk')
# print(df.head())

# # 数据探索
# print('data.shape:', '-' * 50, '\n', data.shape)
# print('data.info:', '-' * 50, '\n', data.info())
# print('data.dtypes:', '-' * 50, '\n', data.dtypes)
# print('data.head:', '-' * 50, '\n', data.head())
# print('data.describe:', '-' * 50, '\n', data.describe())
# print('缺失值个数:', '-' * 50, '\n', data.isnull().sum())

# 图1
sort_info = data.groupby('城市')['新增确诊'].sum().sort_values(ascending=False).head(20)
# print(sort_info)
# bar1 = Bar(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# bar1.add_xaxis(sort_info.index.tolist())
# bar1.add_yaxis('新增确诊', sort_info.values.tolist())
# bar1.reversal_axis()
# bar1.set_series_opts(label_opts=opts.LabelOpts(position="right"))
# bar1.set_global_opts(
#     title_opts=opts.TitleOpts(title='2020-1-10至6-30 新增确诊前20城市', pos_top='bottom'),
#     yaxis_opts=opts.AxisOpts(name='城市'),
#     xaxis_opts=opts.AxisOpts(name='新增确诊'),
# )
# make_snapshot(driver, bar1.render("新增确诊前20城市.html"), '.\\images\\新增确诊前20城市.png')
# print('图1', '-' * 80)

# 图2
data['日期'] = data['日期'].apply(lambda x: x.strftime("%Y-%m-%d"))
pred_cure = data.loc[:, '新增治愈'].head(10)
pred_die = data.loc[:, '新增死亡'].head(10)
# lin1 = Line(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# lin1.add_xaxis(data.loc[:, '日期'].head(10).values.tolist())
# lin1.add_yaxis("新增治愈", pred_cure.values.tolist(), is_smooth=True)
# lin1.add_yaxis("新增死亡", pred_die.values.tolist(), is_smooth=True)
# lin1.set_global_opts(title_opts=opts.TitleOpts(title="前期新增治愈与新增死亡的对比"))
# make_snapshot(driver, lin1.render("前期新增治愈与新增死亡.html"), '.\\images\\前期新增治愈与新增死亡.png')
# print('图2', '-' * 80)

# 图3
cure = data.groupby('城市')['新增治愈'].sum().sort_values(ascending=False).head(10)
# lin2 = Line(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# lin2.add_xaxis(cure.index.tolist())
# lin2.add_yaxis(
#     "新增治愈", cure.values.tolist(), markpoint_opts=opts.MarkPointOpts(data=[opts.MarkPointItem(type_="max")]),
# )
# lin2.set_global_opts(title_opts=opts.TitleOpts(title="新增治愈前10城市"))
# make_snapshot(driver, lin2.render("新增治愈前10城市.html"), '.\\images\\新增治愈前10城市.png')
# print('图3', '-' * 80)

# 图4
die10 = data.groupby('城市')['新增死亡'].sum().sort_values(ascending=False).head(10)
# 图1.实例化Pie类
# pie1 = Pie(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# pie1.add(
#     "",
#     [list(z) for z in zip(die10.index.tolist(), die10.values.tolist())],
#     radius=["40%", "55%"],
#     label_opts=opts.LabelOpts(
#         position="outside",
#         formatter="{b}:{d}%",
#         background_color="#eee",
#         border_color="#aaa",
#         border_width=1,
#         border_radius=4,
#         rich={
#             "a": {"color": "#999", "lineHeight": 22, "align": "center"},
#             "abg": {
#                 "backgroundColor": "#e3e3e3",
#                 "width": "100%",
#                 "align": "right",
#                 "height": 22,
#                 "borderRadius": [4, 4, 0, 0],
#             },
#             "hr": {
#                 "borderColor": "#aaa",
#                 "width": "100%",
#                 "borderWidth": 0.5,
#                 "height": 0,
#             },
#             "b": {"fontSize": 16, "lineHeight": 33},
#             "per": {
#                 "color": "#eee",
#                 "backgroundColor": "#334455",
#                 "padding": [2, 4],
#                 "borderRadius": 2,
#             },
#         },
#     ),
# )
# pie1.set_global_opts(title_opts=opts.TitleOpts(title="新增死亡前10城市", pos_top='bottom'),
#                      legend_opts=opts.LegendOpts(selected_mode="mutiple", orient="vertical", pos_right="30px"))
# make_snapshot(driver, pie1.render("新增死亡前10城市.html"), '.\\images\\新增死亡前10城市.png')
# print('图4', '-' * 80)

# 图5
data['日期'] = pd.to_datetime(data['日期'])
data['月份'] = data['日期'].dt.month
month_df = data.groupby('月份')[['新增治愈', '新增死亡']].sum()
# print(month_df)
sum_df = month_df.sum(axis=1)
# print(sum_df)
x_data = [f"{str(i)}月" for i in month_df.index.tolist()]

# bar2 = Bar(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# bar2.add_xaxis(xaxis_data=x_data)
# bar2.add_yaxis(
#     series_name="总人数",
#     y_axis=sum_df.values.tolist(),
# )
# bar2.add_yaxis(series_name="新增治愈", y_axis=month_df.loc[:, '新增治愈'].values.tolist())
# bar2.add_yaxis(series_name="新增死亡", y_axis=month_df.loc[:, '新增死亡'].values.tolist())
# bar2.set_global_opts(title_opts=opts.TitleOpts(title="2020-1至6月新增治愈与新增死亡变化趋势", pos_top='bottom'),
#                      xaxis_opts=opts.AxisOpts(splitline_opts=opts.SplitLineOpts(is_show=True)),
#                      yaxis_opts=opts.AxisOpts(splitline_opts=opts.SplitLineOpts(is_show=True),
#                                               axislabel_opts=opts.LabelOpts(formatter="{value} /月")), )
# make_snapshot(driver, bar2.render("新增治愈与新增死亡变化趋势.html"), '.\\images\\新增治愈与新增死亡变化趋势.png')
# print('图5', '-' * 80)

# 图6
prov_sum = df.iloc[:, 1] + df.iloc[:, 2] + df.iloc[:, 3]
# print(prov_sum)
df['sum'] = prov_sum
prov_df = df.groupby('provinceName')['sum'].sum()
# print(prov_df)
# m1 = Map(init_opts=opts.InitOpts(theme=ThemeType.PURPLE_PASSION))
# m1.add("感染新冠", [list(z) for z in zip(prov_df.index.tolist(), prov_df.values.tolist())], "china")
# m1.set_global_opts(title_opts=opts.TitleOpts(title="全国感染新冠人数分布"),
#                    visualmap_opts=opts.VisualMapOpts(max_=215016))
# make_snapshot(driver, m1.render("全国感染新冠人数分布.html"), '.\\images\\全国感染新冠人数分布.png')
# print('图6', '-' * 80)
#
# title = Pie()
# title.set_global_opts(
#     title_opts=opts.TitleOpts(title="疫情可视化大屏",
#                               title_textstyle_opts=opts.TextStyleOpts(font_size=40,
#                                                                       border_radius=True, border_color="white"),
#                               pos_top=0))

# # 可视化大屏绘制-------------------------------------------------------------------------------------------------------
# page = Page(layout=Page.DraggablePageLayout)
# page.add(
#     title, bar1, m1, lin2, pie1, bar2, lin1
# )
# # page.render('数据可视化大屏.html')
# with open("数据可视化大屏.html", "r+", encoding='utf-8') as html:
#     html_bf = BeautifulSoup(html, 'lxml')
#     divs = html_bf.select('.chart-container')
#     divs[0]["style"] = "width:40%;height:10%;position:absolute;top:3%;left:50%;"
#     divs[1]["style"] = "width:40%;height:50%;position:absolute;top:10%;left:0%;"
#     divs[2]["style"] = "width:40%;height:102%;position:absolute;top:10%;left:42%;"
#     divs[3]["style"] = "width:40%;height:50%;position:absolute;top:10%;left:84%;"
#     divs[4]["style"] = "width:40%;height:50%;position:absolute;top:62%;left:0%;"
#     divs[5]["style"] = "width:40%;height:50%;position:absolute;top:62%;left:84%;"
#     divs[6]["style"] = "width:124%;height:60%;position:absolute;top:114%;left:0%;"
#     body = html_bf.find("body")
#     body["style"] = "background-color:#9999CC;"  # 背景颜色
#     div_title = r"<div align=\"center\" style=\"width:1200px;\">\n<span style=\"font-size:32px;font " \
#                 r"face=\'黑体\';color:#9999CC\"><b>疫情可视化大屏</b></div>"  # 修改页面背景色、追加标题
#     html_new = str(html_bf)
#     html.seek(0, 0)
#     html.truncate()
#     html.write(html_new)
#     html.close()
# page.save_resize_html("数据可视化大屏.html",
#                       cfg_file="chart_config.json",
#                       dest="mycharts_demo.html")
# print('可视化大屏', '-' * 80)

# 划分特征与目标-----------------------------------------------------------------------------------------------------------------
conv_sum = data.iloc[:, 2] + data.iloc[:, 3] + data.iloc[:, 4]
data['sum'] = conv_sum
X = data.iloc[:, 2:-2].values
Y = data.iloc[:, -1].values.reshape(-1, 1)
# print(X)
# print(X.shape)
# print(Y)
# print(Y.shape)

# 划分训练集与测试集
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)
# print(x_train.shape)
# print(x_test.shape)
# print(y_train.shape)
# print(y_test.shape)

# 建立线性回归模型
print('线性回归模型', '-' * 80)
linear = LinearRegression()
linear.fit(x_train, y_train)
# 模型预测
linear_pred = linear.predict(x_test).flatten()
# print(linear_pred)

# 建立逻辑回归模型
print('逻辑回归模型', '-' * 80)
logistic = LogisticRegression()
# 模型训练
logistic.fit(x_train, y_train)
# 模型预测
logistic_pred = logistic.predict(x_test)
# print(logistic_pred)
arr = np.vstack([linear_pred, logistic_pred])
pred_data = pd.DataFrame(arr, index=['linear_pred', 'logistic_pred']).T
print(pred_data)
pred_data.to_csv('pred_data.csv')
